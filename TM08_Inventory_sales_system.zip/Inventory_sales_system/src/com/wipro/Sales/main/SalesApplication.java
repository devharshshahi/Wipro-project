package com.wipro.Sales.main;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Scanner;

import com.wipro.Sales.bean.Product;
import com.wipro.Sales.bean.Sales;
import com.wipro.Sales.service.Administrator;

public class SalesApplication {
	
	public static void main(String args[])
	{
		
		Scanner sc = new Scanner(System.in);
		
		Administrator admin = new Administrator();
		
		int choice = 0;
		
		do {
			System.out.println("1. Insert Stock");
			System.out.println("2. Delete Stock");
			System.out.println("3. Insert Sales");
			System.out.println("4. View Sales Report");
			System.out.print("Enter your Choice: ");
			choice = sc.nextInt();
			
			switch (choice) {
			case 1:
				Product pr = new Product();
				System.out.print("Enter product ID: ");
				pr.setProductID(sc.nextLine());
				System.out.print("Enter product name: ");
				pr.setProductName(sc.nextLine());
				System.out.print("Enter quantity on hand: ");
				pr.setQuantityOnHand(sc.nextInt());
				sc.nextLine();
				System.out.print("Enter product unit price: ");
				pr.setProductUnitPrice(sc.nextDouble());
				System.out.print("Enter product reorder level: ");
				pr.setReorderLevel(sc.nextInt());
				sc.nextLine();
				admin.insertStock(pr);
				break;
			case 2:
				System.out.print("Enter product id to be deleted: ");
				String removeId = sc.nextLine();
				removeId = admin.deleteStock(removeId);
				if (removeId != null) System.out.println(removeId + " removed successfully");
				break;
			case 3:
				Sales sales = new Sales();
				System.out.print("Enter sales id: ");
				sales.setSalesID(sc.nextLine());
				System.out.print("Enter date (dd-mm-yyyy): ");
				String sDate = sc.nextLine();  
			    Date date = null;
				try {
					date = new SimpleDateFormat("dd-mm-yyyy").parse(sDate);
				} catch (ParseException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				} 
				sales.setSalesDate(date);
				System.out.print("Enter product id: ");
				sales.setProductID(sc.nextLine());
				System.out.print("Enter quantity sold: ");
				sales.setQuantitySold(sc.nextInt());
				sc.nextLine();
				System.out.print("Enter sales price per unit: ");
				sales.setSalesPricePerUnit(sc.nextDouble());
				admin.insertSales(sales);
				break;
			case 4:
				admin.getSalesReport();
				break;
			default:
				System.out.println("Exiting...");
				choice = 0;
				break;
			}
		} while (choice >= 1 && choice <= 4);
		
		sc.close();
	}

}
