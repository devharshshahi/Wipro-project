package com.wipro.Sales.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class DBUtil {
	private static Connection conn = null;
	public static Connection getDBConnection() 
	{
		try 
		{
			Class.forName("oracle.jdbc.driver.OracleDriver");
			conn = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:XE", "hr", "hr");
			return conn;
		} 
		catch (SQLException | ClassNotFoundException e) 
		{
			System.out.println("Connection could not be established");
			e.printStackTrace();
			return null;
		}
	}

}
