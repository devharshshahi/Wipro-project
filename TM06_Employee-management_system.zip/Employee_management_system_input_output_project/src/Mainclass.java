import java.util.Scanner;
import java.io.*;

public class Mainclass {

	public static void main(String[] args) throws IOException {
		System.out.println("Main Menu");
		System.out.println("1. Add an Employee");
		System.out.println("2. Display All");
		System.out.println("3. Exit");
		Scanner sc=new Scanner(System.in);
		int s=sc.nextInt();
		
			switch(s)
			{
				case 1: 
					System.out.print("Enter Employee Id :");
					int id=sc.nextInt();
					System.out.print("Enter Employee Name :");
					String name=sc.next();
					System.out.print("Enter Employee Age :");
					int age=sc.nextInt();
					System.out.print("Enter Employee Salary :");
					float salary=sc.nextFloat();
					String sal=String.valueOf(salary);
					String id1=String.valueOf(id);
					String age1=String.valueOf(age);
					try(FileWriter fw=new FileWriter("MyFile.txt",true);
							 BufferedWriter bw = new BufferedWriter(fw);
							 PrintWriter pw = new PrintWriter(bw);)
					{
						
						pw.print(id1+" ");
						pw.print(name+" ");
						pw.print(age1+" ");
						pw.print(sal);
						pw.close();
					}
						catch(IOException e) 
					{
			            e.printStackTrace();
			        }
					
					break;
				case 2:
					System.out.println("----Report----");
					try 
					{
						FileReader reader = new FileReader("MyFile.txt");
							    int character;
							    
							    while ((character = reader.read()) != -1) {
							        System.out.print(""+(char) character);
							        
							        
							    }
							    System.out.println();
					}
					catch(IOException e) 
					{
			            e.printStackTrace();
			        }
					
					System.out.println("----End of Report----");
					break;
				case 3:
					System.out.println("existing the system");
					break;
			}
	
			
		
	
	}	
	

}
