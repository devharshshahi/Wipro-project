import java.util.ArrayList;

public class StringOperation {
	
	public static void main(String[] args) {
		String s1="JAVAJAVA";
		String s2="VA";
		ArrayList<String> list=new ArrayList<>();
		list=operateString(s1,s2);
		System.out.println(list);
	}
	
	static ArrayList<String> operateString(String s1,String s2){
		ArrayList<String> list=new ArrayList<>(); 
		//Case 1
		StringBuilder st=new StringBuilder("");
		for(int i=0;i<s1.length();i++) {
			if(i%2==0)
				st.append(s2);
			else
				st.append(s1.charAt(i));
		}
		list.add(new String(st));
		
		//case 2 & 3
		st.delete(0,st.length());
		int count=0;
		boolean flag=false;
		int c3=s1.length();
		int s=0;
		int p=0;
		int e=s2.length()-1;
		for(int i=0; i<s1.length();i++) {
			if(flag) {
				if(s1.charAt(i)==s2.charAt(s)) {
					s++;
				}
				else {
					flag=false;
					s=0;
				}
			}else
			{
				if(s1.charAt(i)==s2.charAt(s)) {
					flag=true;
					s++;
					c3=Math.min(c3,i);
				}
			}
			if(e==s) {
				p=i;
				count++;
				s=0;
			}
		}
		StringBuffer st2= new StringBuffer("");
		if(count>1) {
			st.append(s1.substring(0, p));
			for(int i=e;i>=0;i--) {
				st.append(s2.charAt(i));
			}
			st.append(s1.substring(p+e+1, s1.length()));
			st2.append(s1.substring(0,c3));
			st2.append(s1.substring(c3+e+1, s1.length()));
		}
		else {
			st.append(s1+s2);
			st2.append(s1);
		}
		list.add(new String(st));
		list.add(new String(st2));
		
		//Case 4
		st.delete(0, st.length());
		int n=s2.length();
		st.append((n%2==0)?s2.substring(0, n/2):s2.substring(0,(n/2)+1));
		st.append(s1);
		st.append((n%2==0)?s2.substring((n/2), n):s2.substring((n/2)+1,n));
		list.add(new String(st));
		
		//Case 5
		
		st.delete(0, st.length());
		for(int i=0;i<s1.length();i++) {
			if(s2.contains(String.valueOf(s1.charAt(i))))
				st.append("*");
			else
				st.append(s1.charAt(i));
		}
		list.add(new String(st));
		
		
		
		return list;
	}

}
