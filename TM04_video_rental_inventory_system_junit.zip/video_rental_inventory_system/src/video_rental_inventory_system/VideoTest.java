package video_rental_inventory_system;

import static org.junit.Assert.*;

import org.junit.Test;

public class VideoTest {

	@Test
	public void testGetName() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoCheckout() {
		fail("Not yet implemented");
	}

	@Test
	public void testDoReturn() {
		fail("Not yet implemented");
	}

	@Test
	public void testReceiveRating() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetRating() {
		fail("Not yet implemented");
	}

	@Test
	public void testGetCheckOut() {
		fail("Not yet implemented");
	}

	@Test
	public void testVideo() {
		fail("Not yet implemented");
	}

}
