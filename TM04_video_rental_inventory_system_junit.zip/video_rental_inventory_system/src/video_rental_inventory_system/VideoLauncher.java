package video_rental_inventory_system;

import java.util.Scanner;

public class VideoLauncher {

	public static void main(String[] args) {
			
			VideoStore vstore=new VideoStore();
			int a=0;
			Scanner sc=new Scanner(System.in);
		do
		{
			
		
			System.out.println("MAIN MENU");
			System.out.println("==========");
			System.out.println("1.Add Video :");
			System.out.println("2.Check Out Video :");
			System.out.println("3.Return Video :");
			System.out.println("4.Receive Rating :");
			System.out.println("5.List Inventory :");
			System.out.println("6.Exit :");
			System.out.print("Enter Your choice (1..6):");
			
			 a=sc.nextInt();
			String vname;
			switch(a)
			{
			case 1:
				System.out.print("Enter the name of the video you want to add:");
				vname=sc.next();
				vstore.addVideo(vname);
				System.out.println("Video " + vname + " added successfully.");
				break;
			case 2:
				System.out.print("Enter the name of the video you want to check out:");
				vname=sc.next();
				vstore.doCheckout(vname);
				System.out.println("Video " + vname + " checked out successfully.");
				break;
			case 3:
				System.out.print("Enter the name of the video you want to return:");
				vname=sc.next();
				vstore.doReturn(vname);
				System.out.println("Video " + vname + " returned successfully.");
				break;
			case 4:
				System.out.println("Enter the name of the video you want to Rate:");
				vname=sc.next();
				System.out.print("Enter the rating for this video:");
				int rating=sc.nextInt();
				vstore.receiveRating(vname, rating);
				System.out.println("Rating " + rating + " has been mapped to the Video " + vname + ".");
				break;
			case 5:
				vstore.listInventory();
				break;
			default:
				System.out.println("Exiting...!! Thanks for using the application.");
				break;
			}
		
		}
		while (a!= 6);
			sc.close();
		
			
			
	}

}
