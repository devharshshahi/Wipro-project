package com.mile1.exception;

public class NullNameException extends Exception{
	public NullNameException()
	{
		 
	}
public String tostring()
{
	return "NullNameException Occurred";
}
	
}
