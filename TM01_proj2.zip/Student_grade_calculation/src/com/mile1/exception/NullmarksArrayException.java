package com.mile1.exception;

public class NullmarksArrayException extends Exception{
	public NullmarksArrayException()
	{
		
	}

	public String toString() {
		return "NullMarksArrayException Occurred";
	}
}
