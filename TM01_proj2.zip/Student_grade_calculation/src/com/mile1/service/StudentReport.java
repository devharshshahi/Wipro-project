package com.mile1.service;

import java.util.Arrays;

import com.mile1.bean.Student;
import com.mile1.exception.NullNameException;
import com.mile1.exception.NullStudentException;
import com.mile1.exception.NullmarksArrayException;

public class StudentReport {
	public String findGrade(Student studentObject)
	{
		int sum=0;
		int arr[]=studentObject.getMarks();
		String str=Arrays.toString(studentObject.getMarks());
		for(int i=0;i<arr.length;i++)
		{
			sum=sum+arr[i];
		}
		if(sum<35)
		{
			return "F";
		}
		else if(sum<=150)
		{
			return "D";
		}
		else if(sum>150 && sum<=200)
		{
			return "C";
		}
		else if(sum>200 && sum<=250) 
		{
			return "B";
		}
		else if(sum>250 && sum<=300)
		{
			return "A";
		}
		return str;
		
	}
	
	public String validate(Student studentObject) throws NullStudentException,NullNameException,NullmarksArrayException
	{
		if(studentObject==null)
		{
			return new NullStudentException().tostring();
		}
		else if(studentObject.getName()==null)
		{
			return new NullNameException().tostring();
			
			
		}
		else if(studentObject.getMarks()==null)
		{
			return new NullmarksArrayException().toString();
		}
		return findGrade(studentObject);
	}
	

}
