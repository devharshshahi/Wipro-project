package com.mile1.service;

import com.mile1.bean.Student;

public class StudentService {

	public int findNumberOfNullMarks(Student data[])
	{
		int count=0;
		for(Student x: data) {
			if(x==null)
				continue;
		if(x.getMarks()==null)
		{
			count=count+1;
		}
		}
		return count;
	}
	
	public int findNumberOfNullNames(Student data[])
	{
		int count=0;
		for(Student x: data) {
			if(x==null)
				continue;
			if(x.getName()==null)
			{
				count=count+1;
			}
			}
			return count;
	}
	public int findNumberOfNullObjects(Student data[])
	{
		int count=0;
		for(Student x: data) {
			
			if(x==null)
			{
				count=count+1;
			}
			}
			return count;
		
	}

}
