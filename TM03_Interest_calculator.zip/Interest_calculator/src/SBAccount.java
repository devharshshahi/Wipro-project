import java.util.Scanner;

public class SBAccount extends Account{
double interestRate;
double amount;
	@Override
	public double calculateInterest() {
		try
		{
			System.out.print("Enter the Average amount in your account: ");
			Scanner sc=new Scanner(System.in);
			while (amount < 0) {
				System.out.println("Invalid Amount Please enter non - negative values.");
				System.out.print("\nEnter the Average amount in your account: ");
				amount = sc.nextInt();
			}
			amount=sc.nextDouble();
			interestRate=(amount/100)*4;
			
		}
	catch(Exception e)
		{
		e.printStackTrace();
		}
		System.out.println("Interest gained: Rs. "+interestRate);
		return interestRate;
	}
	

}
