import java.util.Scanner;

public class Main {

	public static void main(String[] args) {
		System.out.print("MAIN MENU \n"+"-------- \n"+"1. Interest Calculator -SB\n"+
				"2. Interest Calculator -FD \n"+
				"3. Interest Calculator -RD\n"+
				"4. Exit \n"+
				"Enter your option(1..4):");
		Scanner sc=new Scanner(System.in);
		int a=sc.nextInt();
		switch(a)
		{
		case 1:
			Account sbaccount=new SBAccount();
			sbaccount.calculateInterest();
			break;
		case 2:
			Account fdaccount=new FDAccount();
			fdaccount.calculateInterest();
			break;
		case 3:
			Account rdaccount=new RDAccount();
			rdaccount.calculateInterest();
			break;			
		case 4:
			System.out.println("Thanks for using Interest Calculator");
			break;
			default:
				System.out.println("please choose between 1..4");
				
		}
		
		

	}

}
