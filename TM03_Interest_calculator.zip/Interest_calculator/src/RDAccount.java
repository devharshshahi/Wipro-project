import java.util.Scanner;

public class RDAccount extends Account {
double interestRate;
double amount;
int noOfMonths;
double monthlyAmount;
int age;
Scanner sc=new Scanner(System.in);
	@Override
	public double calculateInterest() {
		System.out.print("Enter the RD ammount: ");
		amount=sc.nextDouble();
		
		System.out.print("Enter number of months: ");
		int noOfMonths = sc.nextInt();
		while (noOfMonths < 0) {
			System.out.println("Invalid Number of months. Please enter non - negative values.");
			System.out.print("Enter number of months: ");
			noOfMonths = sc.nextInt();
		}
		System.out.print("Enter the age: ");
		int age = sc.nextInt();
		while (noOfMonths < 0) {
			System.out.println("Invalid age. Please enter non - negative values.");
			System.out.print("Enter the age: ");
			noOfMonths = sc.nextInt();
		}
		
		if(age<60)
		{
		if (noOfMonths >= 6 && noOfMonths < 9) {
			interestRate = (amount/100)*7.5;
		} 
		else if (noOfMonths >= 9 && noOfMonths < 12) 
		{
			interestRate=(amount/100)* 7.75;
		} 
		else if (noOfMonths >= 12 && noOfMonths < 15)
		{
			interestRate = (amount/100)*8;
		} 
		else if (noOfMonths >= 15 && noOfMonths < 18) 
		{
			interestRate =(amount/100)* 8.25;
		} 
		else if (noOfMonths >= 18 && noOfMonths <= 21)
		{
			interestRate = (amount/100)*8.50;
		} 
		else if (noOfMonths >= 21) 
		{
			interestRate = (amount/100)*8.75;
		}
		}
		else
		{
			if (noOfMonths >= 6 && noOfMonths < 9) {
				interestRate = (amount/100)*8.00;
			} 
			else if (noOfMonths >= 9 && noOfMonths < 12) 
			{
				interestRate=(amount/100)* 8.25;
			} 
			else if (noOfMonths >= 12 && noOfMonths < 15)
			{
				interestRate = (amount/100)*8.50;
			} 
			else if (noOfMonths >= 15 && noOfMonths < 18) 
			{
				interestRate =(amount/100)* 8.75;
			} 
			else if (noOfMonths >= 18 && noOfMonths <= 21)
			{
				interestRate = (amount/100)*9.00;
			} 
			else if (noOfMonths >= 21) 
			{
				interestRate = (amount/100)*9.25;
			}
		}
		
		System.out.println("Interest gained: Rs. "+interestRate);
		return interestRate;
		
	}
	

}
