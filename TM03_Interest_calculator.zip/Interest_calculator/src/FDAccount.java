import java.util.Scanner;

public class FDAccount extends Account{
	double interestRate;
	double amount;
	int noOfDays;
	int ageOfACHolder;
	Scanner sc=new Scanner(System.in);
	@Override
	public double calculateInterest() {
		try
		{
		System.out.print("Enter the FD amount: ");
		amount=sc.nextDouble();
		System.out.print("Enter the number of days: ");
		noOfDays=sc.nextInt();
		while (noOfDays < 0) {
			System.out.println("Invalid Number of days. Please enter non - negative values.");
			System.out.print("\nEnter the number of days: ");
			noOfDays = sc.nextInt();
		}
		System.out.print("Enter your age: ");
		ageOfACHolder=sc.nextInt();
		while (ageOfACHolder < 0) {
			System.out.println("Invalid age. Please enter non - negative values.");
			System.out.print("\nEnter your age: ");
			ageOfACHolder = sc.nextInt();
		}
		if(amount<10000000 && ageOfACHolder<60)
		{
			if(noOfDays>=7 && noOfDays<=14)
			{
				interestRate=(amount/100)*4.50;
			}
			if(noOfDays>=15 && noOfDays<=29)
			{
				interestRate=(amount/100)*4.75;
			}
			if(noOfDays>=30 && noOfDays<=45)
			{
				interestRate=(amount/100)*5.50;
			}
			if(noOfDays>=46 && noOfDays<=60)
			{
				interestRate=(amount/100)*7;
			}
			if(noOfDays>=61 && noOfDays<=184)
			{
				interestRate=(amount/100)*7.50;
			}
			if(noOfDays>=185 && noOfDays<=365)
			{
				interestRate=(amount/100)*8.00;
			}
						
		}
		else if(amount<10000000 && ageOfACHolder>=60)
		{
			if(noOfDays>=7 && noOfDays<=14)
			{
				interestRate=(amount/100)*5.00;
			}
			if(noOfDays>=15 && noOfDays<=29)
			{
				interestRate=(amount/100)*5.25;
			}
			if(noOfDays>=30 && noOfDays<=45)
			{
				interestRate=(amount/100)*6.00;
			}
			if(noOfDays>=46 && noOfDays<=60)
			{
				interestRate=(amount/100)*7.50;
			}
			if(noOfDays>=61 && noOfDays<=184)
			{
				interestRate=(amount/100)*8.00;
			}
			if(noOfDays>=185 && noOfDays<=365)
			{
				interestRate=(amount/100)*8.50;
			}
		}
			else
			{
				if(noOfDays>=7 && noOfDays<=14)
				{
					interestRate=(amount/100)*6.50;
				}
				if(noOfDays>=15 && noOfDays<=29)
				{
					interestRate=(amount/100)*6.75;
				}
				if(noOfDays>=30 && noOfDays<=45)
				{
					interestRate=(amount/100)*6.75;
				}
				if(noOfDays>=46 && noOfDays<=60)
				{
					interestRate=(amount/100)*8;
				}
				if(noOfDays>=61 && noOfDays<=184)
				{
					interestRate=(amount/100)*8.50;
				}
				if(noOfDays>=185 && noOfDays<=365)
				{
					interestRate=(amount/100)*10.00;
				}
			}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		System.out.println("Interest gained: Rs. "+interestRate);
		return interestRate;
	}

}
