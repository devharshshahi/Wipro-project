import java.util.ArrayList;
import java.util.Collection;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

public class Main {
	List<String> list=new ArrayList<String>();
	 
	public void additem()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the item to be inserted");
		String name=sc.nextLine();
		list.add(name);
		System.out.println("Inserted successfully");
		
	}
	public void printAll()
	{
		if(list.isEmpty())
		{
			System.out.println("The list is empty");
		}
		else
		System.out.println("The item in the list are:");
		Iterator<String> itr=list.iterator();
		while(itr.hasNext())
			
			System.out.println(itr.next());
		
		
	}
	public void search()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the item to be search :");
		String search=sc.nextLine();
		if(list.contains(search))
		{
			System.out.println("Item found in the list");
		}
		else
			System.out.println("Item not found in the list");
			
	}
	public void delete()
	{
		Scanner sc=new Scanner(System.in);
		System.out.println("Enter the item to delete:");
		String delete=sc.nextLine();
		if(list.contains(delete))
		{
			list.remove(delete);
			System.out.println("Deleted successfully");
		}
		else
			System.out.println("Item not found in the list");
	}
	public static void main(String[] args) {
		Scanner sc=new Scanner(System.in);
		Main obj=new Main();
		int input;
		do
		{
			
			System.out.println("1.Insert\n"+"2.Search\n"+"3.Delete\n"+"4.Display\n"+"5.Exit\n"+"Enter your choice:");
			input=sc.nextInt();
			switch(input)
			{
			case 1:
				obj.additem();
				break;
			case 2:
				obj.search();
				break;
			case 3:
				obj.delete();
				break;
			case 4:
				obj.printAll();
				break;
			case 5:
				System.out.println("Exit successfully");
				break;
				default:
					System.out.println("please enter between 1..5");
					break;
			}
		}
		while(input!=5);
		sc.close();

	}

}
